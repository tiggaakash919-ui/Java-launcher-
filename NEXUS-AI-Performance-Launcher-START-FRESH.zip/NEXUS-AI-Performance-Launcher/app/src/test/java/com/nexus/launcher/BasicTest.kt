package com.nexus.launcher

import org.junit.Assert.assertTrue
import org.junit.Test

class BasicTest {
    @Test
    fun profileNamesAreNotBlank() {
        val profiles = listOf(
            "Maximum Responsiveness",
            "Sustained Gaming",
            "Balanced",
            "Battery Efficiency",
            "Custom AI"
        )
        assertTrue(profiles.all { it.isNotBlank() })
    }
}
