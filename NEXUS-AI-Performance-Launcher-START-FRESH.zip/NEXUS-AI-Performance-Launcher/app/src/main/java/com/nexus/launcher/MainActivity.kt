package com.nexus.launcher

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Display
import android.hardware.display.DisplayManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF10131A)
private val Panel = Color(0xFF1A202B)
private val Cyan = Color(0xFF66E3FF)
private val Violet = Color(0xFF9A8CFF)

private data class LauncherApp(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)

private data class DeviceMetrics(
    val ramPercent: Int?,
    val batteryTempC: Float?,
    val refreshRateHz: Float?,
    val batteryPercent: Int?
)

private enum class Page { HOME, APPS, PERFORMANCE, SETTINGS }

class MainActivity : ComponentActivity() {
    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("nexus_preferences", Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var darkTheme by remember { mutableStateOf(prefs.getBoolean("dark_theme", true)) }
            val appsState = remember { mutableStateOf<List<LauncherApp>>(emptyList()) }
            var metrics by remember { mutableStateOf(DeviceMetrics(null, null, null, null)) }
            var page by remember { mutableStateOf(Page.HOME) }
            var search by remember { mutableStateOf("") }
            var profile by remember { mutableStateOf(prefs.getString("profile", "Balanced") ?: "Balanced") }
            var gamingMode by remember { mutableStateOf(prefs.getBoolean("gaming_mode", false)) }
            var showLabels by remember { mutableStateOf(prefs.getBoolean("show_labels", true)) }
            var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", mutableSetOf<String>())?.toSet() ?: emptySet()) }

            LaunchedEffect(Unit) {
                appsState.value = withContext(Dispatchers.IO) { loadLaunchableApps() }
                while (true) {
                    metrics = withContext(Dispatchers.IO) { readMetrics() }
                    delay(5000)
                }
            }

            val apps = appsState.value
            val filteredApps = apps.filter {
                it.label.contains(search, ignoreCase = true) ||
                    it.packageName.contains(search, ignoreCase = true)
            }
            val sortedFavorites = apps.filter { it.packageName in favorites }
            val recentApps = sortedFavorites.take(6)

            MaterialTheme(
                colorScheme = if (darkTheme) darkColorScheme(
                    primary = Cyan,
                    secondary = Violet,
                    background = Ink,
                    surface = Panel,
                    onBackground = Color(0xFFF4F7FB),
                    onSurface = Color(0xFFF4F7FB)
                ) else lightColorScheme(
                    primary = Color(0xFF006B80),
                    secondary = Color(0xFF6553B8)
                )
            ) {
                Scaffold(
                    containerColor = if (darkTheme) Ink else MaterialTheme.colorScheme.background,
                    bottomBar = {
                        NavigationBar(containerColor = if (darkTheme) Panel else MaterialTheme.colorScheme.surface) {
                            NavigationBarItem(
                                selected = page == Page.HOME,
                                onClick = { page = Page.HOME },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home") }
                            )
                            NavigationBarItem(
                                selected = page == Page.APPS,
                                onClick = { page = Page.APPS },
                                icon = { Icon(Icons.Default.Apps, contentDescription = "Apps") },
                                label = { Text("Apps") }
                            )
                            NavigationBarItem(
                                selected = page == Page.PERFORMANCE,
                                onClick = { page = Page.PERFORMANCE },
                                icon = { Icon(Icons.Default.Bolt, contentDescription = "Performance") },
                                label = { Text("Performance") }
                            )
                            NavigationBarItem(
                                selected = page == Page.SETTINGS,
                                onClick = { page = Page.SETTINGS },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") }
                            )
                        }
                    }
                ) { padding ->
                    when (page) {
                        Page.HOME -> HomePage(
                            modifier = Modifier.padding(padding),
                            metrics = metrics,
                            favoriteApps = recentApps,
                            showLabels = showLabels,
                            onOpenApps = { page = Page.APPS },
                            onOpenPerformance = { page = Page.PERFORMANCE },
                            onLaunch = ::launchApp
                        )
                        Page.APPS -> AppsPage(
                            modifier = Modifier.padding(padding),
                            apps = filteredApps,
                            search = search,
                            onSearch = { search = it },
                            favorites = favorites,
                            showLabels = showLabels,
                            onLaunch = ::launchApp,
                            onToggleFavorite = { app ->
                                favorites = if (app.packageName in favorites) favorites - app.packageName else favorites + app.packageName
                                prefs.edit().putStringSet("favorites", favorites).apply()
                            }
                        )
                        Page.PERFORMANCE -> PerformancePage(
                            modifier = Modifier.padding(padding),
                            metrics = metrics,
                            selectedProfile = profile,
                            gamingMode = gamingMode,
                            onProfile = {
                                profile = it
                                prefs.edit().putString("profile", it).apply()
                            },
                            onGamingMode = {
                                gamingMode = it
                                prefs.edit().putBoolean("gaming_mode", it).apply()
                            }
                        )
                        Page.SETTINGS -> SettingsPage(
                            modifier = Modifier.padding(padding),
                            darkTheme = darkTheme,
                            onDarkTheme = {
                                darkTheme = it
                                prefs.edit().putBoolean("dark_theme", it).apply()
                            },
                            showLabels = showLabels,
                            onShowLabels = {
                                showLabels = it
                                prefs.edit().putBoolean("show_labels", it).apply()
                            },
                            onDefaultHome = {
                                runCatching { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                                    .recoverCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                            },
                            onRefreshApps = {
                                appsState.value = loadLaunchableApps()
                            }
                        )
                    }
                }
            }
        }
    }

    private fun launchApp(app: LauncherApp) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { startActivity(intent) }
    }

    @Suppress("DEPRECATION")
    private fun loadLaunchableApps(): List<LauncherApp> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
            .asSequence()
            .filter { it.activityInfo.packageName != packageName }
            .mapNotNull { resolve ->
                runCatching {
                    LauncherApp(
                        label = resolve.loadLabel(packageManager).toString(),
                        packageName = resolve.activityInfo.packageName,
                        activityName = resolve.activityInfo.name,
                        icon = resolve.loadIcon(packageManager)
                    )
                }.getOrNull()
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .toList()
    }

    @Suppress("DEPRECATION")
    private fun readMetrics(): DeviceMetrics {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(memory)
        val ramPercent = if (memory.totalMem > 0L) {
            (((memory.totalMem - memory.availMem) * 100L) / memory.totalMem).toInt().coerceIn(0, 100)
        } else null

        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val batteryTemp = if (rawTemp >= 0) rawTemp / 10f else null
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPercent = if (level >= 0 && scale > 0) (level * 100 / scale) else null

        val displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        return DeviceMetrics(ramPercent, batteryTemp, display?.refreshRate, batteryPercent)
    }
}

private fun Drawable.toBitmapIcon(): androidx.compose.ui.graphics.ImageBitmap {
    val width = intrinsicWidth.takeIf { it > 0 }?.coerceAtMost(192) ?: 96
    val height = intrinsicHeight.takeIf { it > 0 }?.coerceAtMost(192) ?: 96
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, width, height)
    draw(canvas)
    return bitmap.asImageBitmap()
}

@Composable
private fun AppTile(
    app: LauncherApp,
    showLabel: Boolean,
    favorite: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Box {
                Image(
                    bitmap = remember(app.icon) { app.icon.toBitmapIcon() },
                    contentDescription = app.label,
                    modifier = Modifier.size(48.dp)
                )
                if (favorite) {
                    Text("★", color = Cyan, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd))
                }
            }
            if (showLabel) {
                Text(
                    app.label,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 13.sp
                )
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String? = null) {
    Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Cyan)
    if (subtitle != null) {
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.72f))
    }
}

@Composable
private fun MetricCard(title: String, value: String, footnote: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = Cyan)
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
            Text(footnote, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        }
    }
}

@Composable
private fun HomePage(
    modifier: Modifier,
    metrics: DeviceMetrics,
    favoriteApps: List<LauncherApp>,
    showLabels: Boolean,
    onOpenApps: () -> Unit,
    onOpenPerformance: () -> Unit,
    onLaunch: (LauncherApp) -> Unit
) {
    val clock = remember { SimpleDateFormat("EEEE, d MMM", Locale.getDefault()) }
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NEXUS", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Cyan)
                Text(clock.format(now), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
            }
            Box(
                Modifier.size(54.dp).clip(CircleShape).background(Panel),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = Violet, modifier = Modifier.size(30.dp))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("YOUR DEVICE. YOUR CONTROL.", fontWeight = FontWeight.Bold, color = Cyan)
                Text("A lightweight home for your apps, with transparent device readings and simple gaming profiles.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onOpenApps) { Icon(Icons.Default.Apps, null); Spacer(Modifier.width(6.dp)); Text("All apps") }
                    Button(onClick = onOpenPerformance) { Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(6.dp)); Text("Performance") }
                }
            }
        }
        Text("DEVICE SNAPSHOT", fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("System RAM", metrics.ramPercent?.let { "$it%" } ?: "N/A", "System-wide usage", Modifier.weight(1f))
            MetricCard("Battery", metrics.batteryPercent?.let { "$it%" } ?: "N/A", "Reported level", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Battery temp", metrics.batteryTempC?.let { String.format(Locale.getDefault(), "%.1f°C", it) } ?: "N/A", "Not CPU/GPU temp", Modifier.weight(1f))
            MetricCard("Refresh rate", metrics.refreshRateHz?.let { "${it.toInt()} Hz" } ?: "N/A", "Current display mode", Modifier.weight(1f))
        }
        if (metrics.batteryTempC != null && metrics.batteryTempC >= 42f) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF512A2A))) {
                Text(
                    "Battery temperature is elevated. Consider pausing demanding use and letting the phone cool.",
                    modifier = Modifier.padding(14.dp),
                    color = Color.White
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("FAVORITES", fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
            Text("Long-press is not required: use Apps to star apps", fontSize = 10.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
        if (favoriteApps.isEmpty()) {
            Text("No favorites yet. Open Apps and tap ★ to add your favorite apps.")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxWidth().height(((favoriteApps.size + 2) / 3 * 100).coerceAtLeast(100).dp),
                contentPadding = PaddingValues(2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(favoriteApps, key = { it.packageName }) {
                    AppTile(it, showLabels, favorite = true, onClick = { onLaunch(it) })
                }
            }
        }
        Text(
            "NEXUS does not overclock the CPU/GPU or override Android thermal protection.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
    }
}

@Composable
private fun AppsPage(
    modifier: Modifier,
    apps: List<LauncherApp>,
    search: String,
    onSearch: (String) -> Unit,
    favorites: Set<String>,
    showLabels: Boolean,
    onLaunch: (LauncherApp) -> Unit,
    onToggleFavorite: (LauncherApp) -> Unit
) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 18.dp)) {
        PageHeader("Applications", "${apps.size} launchable activities")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = search,
            onValueChange = onSearch,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Search apps") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 88.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            items(apps, key = { it.packageName + "/" + it.activityName }) { app ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AppTile(
                        app = app,
                        showLabel = showLabels,
                        favorite = app.packageName in favorites,
                        onClick = { onLaunch(app) }
                    )
                    Text(
                        if (app.packageName in favorites) "★ Favorited" else "☆ Add favorite",
                        fontSize = 10.sp,
                        color = Cyan,
                        modifier = Modifier.align(Alignment.CenterHorizontally).clickable { onToggleFavorite(app) }.padding(3.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PerformancePage(
    modifier: Modifier,
    metrics: DeviceMetrics,
    selectedProfile: String,
    gamingMode: Boolean,
    onProfile: (String) -> Unit,
    onGamingMode: (Boolean) -> Unit
) {
    val profiles = listOf(
        "Maximum Responsiveness",
        "Sustained Gaming",
        "Balanced",
        "Battery Efficiency",
        "Custom AI"
    )
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        PageHeader("Performance", "Transparent monitoring • safe profile preferences")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ACTIVE PREFERENCE", color = Cyan, fontWeight = FontWeight.Bold)
                Text(selectedProfile, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(profileDescription(selectedProfile))
            }
        }
        Text("SELECT PROFILE", fontWeight = FontWeight.Bold)
        profiles.forEach { item ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onProfile(item) },
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedProfile == item) Color(0xFF243746) else Panel
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item, fontWeight = FontWeight.SemiBold)
                        Text(profileDescription(item), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    }
                    if (selectedProfile == item) Text("✓", color = Cyan, fontSize = 22.sp)
                }
            }
        }
        Divider(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Gaming session flag", fontWeight = FontWeight.Bold)
                Text("A local preference only; it does not change system clocks or block background apps.", fontSize = 12.sp)
            }
            Switch(checked = gamingMode, onCheckedChange = onGamingMode)
        }
        Text("LIVE READINGS", fontWeight = FontWeight.Bold)
        MetricCard("System RAM", metrics.ramPercent?.let { "$it%" } ?: "N/A", "Whole-device estimate", Modifier.fillMaxWidth())
        MetricCard("Battery temperature", metrics.batteryTempC?.let { String.format(Locale.getDefault(), "%.1f°C", it) } ?: "N/A", "Battery sensor only", Modifier.fillMaxWidth())
        if (metrics.batteryTempC != null && metrics.batteryTempC >= 42f) {
            Text("Heat warning: stop intensive use if the phone becomes uncomfortably hot. Android thermal safeguards remain in control.", color = MaterialTheme.colorScheme.error)
        }
        Text(
            "Important: Android does not let ordinary apps reliably force CPU/GPU frequencies, promise extra FPS, or bypass thermal limits. This screen stores preferences and shows available readings; it does not claim to boost hardware.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f)
        )
    }
}

private fun profileDescription(profile: String): String = when (profile) {
    "Maximum Responsiveness" -> "Preference for a responsive-feeling, minimal launcher experience."
    "Sustained Gaming" -> "Prioritizes awareness of sustained use and heat; no clock changes."
    "Battery Efficiency" -> "A reminder-oriented profile for lighter use and fewer unnecessary checks."
    "Custom AI" -> "Adaptive recommendations are a future capability; no AI tuning runs in this starter."
    else -> "General-purpose default for everyday use."
}

@Composable
private fun SettingsPage(
    modifier: Modifier,
    darkTheme: Boolean,
    onDarkTheme: (Boolean) -> Unit,
    showLabels: Boolean,
    onShowLabels: (Boolean) -> Unit,
    onDefaultHome: () -> Unit,
    onRefreshApps: () -> Unit
) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        PageHeader("Settings", "Personalize the launcher")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Dark appearance", fontWeight = FontWeight.SemiBold)
                    Text("A dark, low-distraction interface", fontSize = 12.sp)
                }
                Switch(checked = darkTheme, onCheckedChange = onDarkTheme)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("App labels", fontWeight = FontWeight.SemiBold)
                    Text("Show names under app icons", fontSize = 12.sp)
                }
                Switch(checked = showLabels, onCheckedChange = onShowLabels)
            }
        }
        Button(onClick = onDefaultHome, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Home, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Choose NEXUS as default Home app")
        }
        Button(onClick = onRefreshApps, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Refresh, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Refresh app list")
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Privacy & capability", color = Cyan, fontWeight = FontWeight.Bold)
                Text("NEXUS reads app labels/icons and basic system memory, battery level/temperature, and display refresh rate. It does not send telemetry, require an account, or request root access.")
                Text("No CPU/GPU overclocking, thermal-limit bypass, or guaranteed FPS claims.", fontSize = 12.sp)
                Text("Version 1.0.0 • Android 8.0+ (API 26+)", fontSize = 12.sp)
            }
        }
    }
}
