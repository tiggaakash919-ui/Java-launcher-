# NEXUS — Android Home Launcher

A lightweight Kotlin + Jetpack Compose Android HOME launcher prototype.

## Included
- HOME launcher entry point and app drawer
- App search and app launching
- Locally saved favorites
- Home screen system snapshot: system-wide RAM estimate, battery percentage, battery temperature, and display refresh rate when available
- Preference profiles: Maximum Responsiveness, Sustained Gaming, Balanced, Battery Efficiency, and Custom AI
- Gaming-session preference, theme toggle, app-label toggle, app-list refresh
- Basic battery heat warning
- GitHub Actions build and APK artifact workflow

## Honest capability boundaries
- The performance profiles and gaming-session switch store local preferences; they do not overclock CPU/GPU, change refresh-rate policy, kill background apps, or bypass Android thermal safeguards.
- “Custom AI” is a placeholder preference, not an implemented AI model.
- RAM is a whole-system estimate, not NEXUS process memory.
- Battery temperature is not CPU/GPU temperature.
- Device-specific behavior must be tested on physical hardware.

## Build locally
Use JDK 17, Android SDK 35, Gradle 8.9, and run:
`gradle assembleDebug`

## GitHub Actions
The included workflow builds a debug APK and uploads `app-debug.apk` as the `nexus-debug-apk` artifact.
